CMCXmlParser._FilePathToXmlStringMap.Add(
	'Glossary',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<html xmlns:MadCap=\"http://www.madcapsoftware.com/Schemas/MadCap.xsd\" MadCap:disableMasterStylesheet=\"true\" MadCap:tocPath=\"\" MadCap:medium=\"non-print\" MadCap:InPreviewMode=\"false\" MadCap:PreloadImages=\"false\" MadCap:RuntimeFileType=\"Glossary\" MadCap:TargetType=\"WebHelp\" lang=\"en-us\" xml:lang=\"en-us\" MadCap:PathToHelpSystem=\"../\" MadCap:HelpSystemFileName=\"index.xml\">' +
	'    <head>' +
	'        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />' +
	'        <link href=\"SkinSupport/MadCap.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <title>Glossary</title>' +
	'        <link href=\"Opticks_Styles.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <script src=\"SkinSupport/MadCapAll.js\" type=\"text/javascript\">' +
	'        </script>' +
	'    </head>' +
	'    <body style=\"background-color: #fafafa;\">' +
	'        <div id=\"GlossaryBody\">' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_0\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">AOI</a>' +
	'                    <a name=\"2397783520_anchor1\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_0\" style=\"display: none;\">Area Of Interest</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_1\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">ASPAM</a>' +
	'                    <a name=\"2397783520_anchor2\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_1\" style=\"display: none;\">Atmospheric Slant Path Analysis Model</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_2\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">AVI</a>' +
	'                    <a name=\"2397783520_anchor3\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_2\" style=\"display: none;\">Audio Video Interleaved</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_3\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">DEM</a>' +
	'                    <a name=\"2397783520_anchor4\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_3\" style=\"display: none;\">Digital Elevation Map</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_4\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">ENVI</a>' +
	'                    <a name=\"2397783520_anchor5\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_4\" style=\"display: none;\">ENvironment for Visualizing Images</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_5\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">GCP</a>' +
	'                    <a name=\"2397783520_anchor6\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_5\" style=\"display: none;\">Ground Control Point</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_6\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">GeoTIFF</a>' +
	'                    <a name=\"2397783520_anchor7\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_6\" style=\"display: none;\">Georeference Tagged Image File Format</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_7\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">GIS</a>' +
	'                    <a name=\"2397783520_anchor8\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_7\" style=\"display: none;\">Geographic Information System</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_8\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">JPEG</a>' +
	'                    <a name=\"2397783520_anchor9\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_8\" style=\"display: none;\">Joint Photographic Experts Group</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_9\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">JPG</a>' +
	'                    <a name=\"2397783520_anchor10\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_9\" style=\"display: none;\">Joint Photographic Experts Group</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_10\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">MGRS</a>' +
	'                    <a name=\"2397783520_anchor11\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_10\" style=\"display: none;\">Military Grid Reference System</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_11\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">MPEG</a>' +
	'                    <a name=\"2397783520_anchor12\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_11\" style=\"display: none;\">Moving Picture Experts Group</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_12\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">NIR</a>' +
	'                    <a name=\"2397783520_anchor13\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_12\" style=\"display: none;\">Near Infrared</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_13\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">NITF</a>' +
	'                    <a name=\"2397783520_anchor14\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_13\" style=\"display: none;\">National Imagery Transmission Format</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_14\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">PCA</a>' +
	'                    <a name=\"2397783520_anchor15\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_14\" style=\"display: none;\">Principal Component Analysis</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_15\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">PNG</a>' +
	'                    <a name=\"2397783520_anchor16\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_15\" style=\"display: none;\">Portable Network Graphic</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_16\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">RGB</a>' +
	'                    <a name=\"2397783520_anchor17\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_16\" style=\"display: none;\">Red-Green-Blue</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_17\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">ROI</a>' +
	'                    <a name=\"2397783520_anchor18\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_17\" style=\"display: none;\">Region of Interest</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_18\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">RPC</a>' +
	'                    <a name=\"2397783520_anchor19\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_18\" style=\"display: none;\">Rapid Positioning Coefficient</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_19\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">signature</a>' +
	'                    <a name=\"2397783520_anchor20\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_19\" style=\"display: none;\">A signature is a distinctive mark or characteristic indicating the identity of a target.</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_20\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">SWIR</a>' +
	'                    <a name=\"2397783520_anchor21\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_20\" style=\"display: none;\">Short-wave Infrared</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_21\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">TIFF</a>' +
	'                    <a name=\"2397783520_anchor22\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_21\" style=\"display: none;\">Tagged Image File Format</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2397783520_22\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">UTM</a>' +
	'                    <a name=\"2397783520_anchor23\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2397783520_22\" style=\"display: none;\">Universal Transverse Mercator</div>' +
	'            </div>' +
	'        </div>' +
	'        <p>&#160;</p>' +
	'        <script type=\"text/javascript\" src=\"SkinSupport/MadCapBodyEnd.js\">' +
	'        </script>' +
	'    </body>' +
	'</html>'
);
