CMCXmlParser._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><CatapultToc Version=\"1\" DescendantCount=\"232\"><TocEntry Title=\"Opticks\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"231\"><TocEntry Title=\"Welcome\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"0\" /><TocEntry Title=\"Opticks Studio\" Link=\"/Content/Working_with_the_Main_Application_Window.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"228\" Chunk=\"Toc_Chunk1.xml\"></TocEntry><TocEntry Title=\"Opticks Websites\" Link=\"/Content/Opticks_Websites.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" /></TocEntry></CatapultToc>'
);
