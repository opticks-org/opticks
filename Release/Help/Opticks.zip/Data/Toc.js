CMCXmlParser._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?><CatapultToc Version=\"1\" DescendantCount=\"252\"><TocEntry Title=\"Opticks\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"251\" Chunk=\"Toc_Chunk1.xml\"></TocEntry></CatapultToc>'
);
