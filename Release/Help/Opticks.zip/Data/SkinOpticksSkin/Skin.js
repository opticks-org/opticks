CMCXmlParser._FilePathToXmlStringMap.Add(
	'Skin',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultSkin Version=\"1\" Comment=\"Silver theme skin\" Anchors=\"Width,Height\" Width=\"800px\" Height=\"600px\" Top=\"0px\" Left=\"0px\" Bottom=\"0px\" Right=\"0px\" Tabs=\"TOC,Index,Search,Glossary,Favorites\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"True\" Title=\"Opticks Help\">' +
	'    <Index BinaryStorage=\"True\" />' +
	'    <HtmlHelpOptions ShowMenuBar=\"False\" TopmostWindowStyle=\"False\" Buttons=\"Hide,Locate,Back,Forward,Stop,Refresh,Home,Font,Print\" EnableButtonCaptions=\"True\" />' +
	'    <Stylesheet Link=\"Stylesheet.xml\">' +
	'    </Stylesheet>' +
	'</CatapultSkin>'
);
