CMCXmlParser._FilePathToXmlStringMap.Add(
	'HelpSystem',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<WebHelpSystem DefaultUrl=\"Content/Welcome.htm\" Toc=\"Data/Toc.xml\" Index=\"Data/Index.xml\" Concepts=\"Data/Concepts.xml\" BrowseSequence=\"Data/BrowseSequences.xml\" Glossary=\"Content/Glossary.htm\" SearchDatabase=\"Data/Search.xml\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" Skin=\"Data/SkinOpticksSkin/Skin.xml\" Skins=\"BlueGov,NewWindow,OpticksSkin,Robin\" BuildTime=\"3/28/2013 11:12:27 AM\" BuildVersion=\"9.0.0.0\" TargetType=\"WebHelp\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\" />'
);
