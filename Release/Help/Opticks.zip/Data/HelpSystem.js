CMCXmlParser._FilePathToXmlStringMap.Add(
	'HelpSystem',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<WebHelpSystem DefaultUrl=\"Content/Welcome.htm\" Toc=\"Data/Toc.xml\" Index=\"Data/Index.xml\" Concepts=\"Data/Concepts.xml\" BrowseSequence=\"Data/BrowseSequences.xml\" Glossary=\"Content/Glossary.htm\" SearchDatabase=\"Data/Search.xml\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" Skin=\"Data/SkinOpticksSkin/Skin.xml\" Skins=\"NewWindow,BlueGov,Robin,OpticksSkin\" BuildTime=\"8/15/2011 11:07:43 AM\" BuildVersion=\"7.1.0.0\" TargetType=\"WebHelp\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\" />'
);
